
% FRUPEN Setup file 

function [K, n,info,Ep,Ek,Kswing1,Kswing2,Mu,eps]= FURPEN_Setup;

%call statespace file equations
FURPEN_SSE;



disp('Control gain');
disp(K);
disp('egianvalues');
disp(eig(A-B*K));

disp("Transfer Function for Furuta Pendulum")
Furuta_tf =tf(Furuta_ss)

end